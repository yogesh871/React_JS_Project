import  "./Pagination.css";

const Pagination = () => {

    

    return (
        <>
            <ul className=" pagination d-flex gap-1 list-unstyled justify-content-center align-items-center flex-wrap">
                <li> Prev</li>
                <li> 1</li>
                <li> 2</li>
                <li> 3</li>
                <li> 4</li>
                <li> 5</li>
                <li> Next</li>
            </ul>
        </>
    )

}
export default Pagination;