import './Top_btn.css'
import { FaLongArrowAltUp } from "react-icons/fa";


const Topbtn = () => {
    return (
        <>
        <div className="top_btn">
     <a href="Blog.jsx"><FaLongArrowAltUp  style={{color:" #fff" , fontSize: "30px"}}/></a>
        </div>
        </>
    )

}
export default Topbtn;