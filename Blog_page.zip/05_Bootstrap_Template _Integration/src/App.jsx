import Blog from "./Components/Blog"
import 'bootstrap/dist/css/bootstrap.min.css';
import  "./App.css";


function App() {

  return (
    <>
   <Blog/>
    </>
  )
}

export default App
